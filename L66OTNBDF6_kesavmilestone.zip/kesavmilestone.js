let plusButton = document.getElementById("plusButton");
let minusButton = document.getElementById("minusButton");
console.log(plusButton, minusButton)

function onPlus() {
    plusButton.classList.add('d-none');
    minusButton.classList.remove('d-none');
}

function onMinus() {
    minusButton.classList.add('d-none');
    plusButton.classList.remove('d-none');
}